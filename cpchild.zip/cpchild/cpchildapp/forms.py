from django.core import validators
from django import forms
from .models import Image, User
class AddDoctF(forms.ModelForm):
    class Meta:
        model=User
        fields=['name','phone','username','password','email','gender','specialization']
        widgets={
            'name': forms.TextInput(attrs={'class':'form-control'}),
            'username': forms.TextInput(attrs={'class':'form-control'}),
            'password': forms.TextInput(attrs={'class':'form-control'}),
            'phone': forms.TextInput(attrs={'class':'form-control'}),
            'email': forms.EmailInput(attrs={'class':'form-control'}),
            'gender': forms.TextInput(attrs={'class':'form-control'}),
            'specialization': forms.TextInput(attrs={'class':'form-control'}),
          
        }
class ImageForm(forms.ModelForm):
    """Form for the image model"""
    class Meta:
        model = Image
        fields = ('title', 'image')

