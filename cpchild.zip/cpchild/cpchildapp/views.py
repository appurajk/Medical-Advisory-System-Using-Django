from django.shortcuts import render,redirect,HttpResponse,HttpResponseRedirect
from django.conf import settings
from .models import User,Patient
from .forms import AddDoctF,ImageForm
import serial 
import numpy as np
import cv2
from PIL import Image as im 
from django.contrib import messages
from django.template import RequestContext
from django.contrib.auth.decorators import login_required
from django.contrib.auth import authenticate, login, logout
from django.contrib import messages
from django.http import request
from django.contrib.auth.models import auth


def AddDoct(request):  
    if request.method =='POST':       
        name=request.POST.get('name','')
        phone=request.POST.get('phone','')
        email=request.POST.get('email','')
        gender=request.POST.get('gender','')
        specialization=request.POST.get('specialization','')    
        username=request.POST.get('username','')
        password=request.POST.get('password','')
        if name and phone and username and password and specialization and gender:           
            reg=User(name=name,phone=phone,email=email,gender=gender,specialization=specialization,username=username,password=password)    
            reg.save()
            messages.success(request,'Doctor details created Successfully')
            return HttpResponse("Details added successfully")
        else:
                # fm=AddDoct()
            return HttpResponse("Enter all details")
    return render(request,'adddoct.html')

   # Function to show all doctors.
   
@login_required(login_url='/login/')   
def ShowDoct(request):
    fm=AddDoctF()
    data=User.objects.all()
    return render(request,'showDoct.html', {'form':fm, 'data':data})

# Function to update doctor details 
def UpdateDoct(request,id):
    if request.method=='POST':
        data=User.objects.filter(id=id) 
        return render(request,'showDoct.html',{'data':data})
        # fm=(request.POST,instance='data')
        if data.is_valid():
            data.save()
        return HttpResponse("Details Updated successfully")
    else:
        data=User.objects.get(id=='id')
        # fm=AddDoct(instance=pi)
    return render(request, 'showDoct.html',{'data':data})

@login_required(login_url='/login/')
def deleteDoct(request,id):
    pi=User.objects.get(id=id)
    if request.method=='POST':
        pi=User.objects.get(id=id)
        pi.delete()
    return HttpResponseRedirect('/showdoctors')

#Function to Store Patient details. 
def Pvalues(request):
    ser=serial.Serial('COM3', baudrate=115200, timeout=1)
    while True:
        print("")
#     """" READING VALUES FROM PORT"""
        pval=ser.readline()
        if pval != None :
            print("Put Pressure on the mat")
            # serial.Serial("com3", 115200).close()
            #     print(type(pval))
        else:
            l=list(pval)
            print(l)

            #     """" RESIZING THE LIST TO 1020 VALUES"""
    
            resize=len(l)-1020  
            l = l[:- resize]
            #     print(len(l))
            #     print(type(l))
            # a=input("Retake (Y)/(N)\n")
            # if a is "N":
            #     serial.Serial("com3", 115200).close()
            break
        
#         """" REARRANGING THE PRESSURE VALUES AS PER OUR SENSORS ARRANGEMENT """
        
    array = np.reshape(l, (-1,34))
    data = im.fromarray(array) 

# """" SAVING PRESSURE VALUES AS PNG IMAGE"""

    data.save('pic.png')	
#cv2.imshow()
    a=cv2.imread("pic.png")

# """" RESIZING THE IMAGE FOR GOOD VISUALIZATION"""

    imgresize=cv2.resize(a,(512,512))
# cv2.imshow("Original",a)
    cv2.imshow("resize",imgresize)
    cv2.waitKey(10000)
    return(l)

def AddPat(request):
    if request.method=="POST":     
        name=request.POST.get('name','')
        img=request.POST.get('img','request.FILES')
        # img = ImageForm(request.POST, request.FILES)
        phone=request.POST.get('phone','')
        email=request.POST.get('email','')
        gender=request.POST.get('gender','')
        pval=request.POST.get('pval','')
        if name and phone and email:
            patient=Patient(name=name,phone=phone,email=email,gender=gender,image=img)
            patient.save()
            # img_obj=img.instance
            # return render(request,'index.html',{'form':img, 'img_obj':img})
            #return HttpResponse("Patient Details added successfully")
        else:
            # form=ImageForm()
            return HttpResponse("Enter all details")
    return render(request,'addPat.html')

def ShowPat(request):
    data=Patient.objects.all()
    return render(request,'showPat.html',{'data':data})

def doctlogin(request):
    if request.method=="POST":
        username = request.POST['username']
        password = request.POST['password']      
        print(username,password)
        User = authenticate(username=username,password=password)
        print(User)
        if User is not None:            
            login(request, User)  
            return render(request,'doctor_page.html')
        else:
            messages.info(request,'Incorrect credentials')
            return render(request,'doctlogin.html')
            # return redirect('login') 
    else:
        return render(request,'doctlogin.html')

def Adminlog(request):
    if request.method=="POST":   
        username = request.POST.get('username')
        password = request.POST.get('password')
        print(username,password)
        User = authenticate(username=username,password=password)
        print(User)
        if User is not None:            
            login(request, User)
            return render(request,'admin_page.html')
        else:
            messages.info(request,'Incorrect credentials')
            return render(request,'doctlogin.html')
    else:    
        return render(request,'adminlog.html')

@login_required(login_url='/doctlog/')
def Admin(request):
    return render(request,'admin_page.html')

def login_user(request):
    return render(request,'doctlogin.html')