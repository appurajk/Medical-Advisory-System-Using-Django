from django.contrib import admin
from django.urls import path,include
from . import views
from django.conf import settings
from django.conf.urls.static import static
urlpatterns = [ 
     path('addDoct',views.AddDoct,name="adddoct"),
     path('',views.doctlogin,name="doctlog"),
     path('adminlog',views.Adminlog,name="adminlog"),
     path('myadmin',views.Admin,name="myadmin"),
     path('showdoctors/',views.ShowDoct,name="showdoctors"),
     path('delete/<id>/',views.deleteDoct,name="delete"),
     path('update/<id>',views.UpdateDoct, name="update"),
     path('addpatient/',views.AddPat,name="addpat"),
     path('showpat/',views.ShowPat,name="showpat"),
     path('p_val/',views.Pvalues,name="p_val"),
     # path(r'^main/$',views.main,name="main"),
     
]
if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL,
                          document_root=settings.MEDIA_ROOT)

