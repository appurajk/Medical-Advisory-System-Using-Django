from django.db import models

# Create your models here.
# GENDER_CHOICES = (
#    ('M', 'Male'),
#    ('F', 'Female')
# )
class User(models.Model):
    id = models.AutoField(primary_key=True)
    name=models.CharField(max_length=50)
    phone=models.CharField(max_length=10)
    email=models.EmailField(max_length=50)
    gender=models.CharField(max_length=50)
    specialization=models.CharField(max_length=50)
    username=models.CharField(max_length=8)
    password=models.CharField(max_length=8)
    
    # def __str__(self):
    #     return self.name
#  gender = models.CharField(choices=GENDER_CHOICES, max_length=128)

class Patient(models.Model):
   id=models.AutoField(primary_key=True)
   image = models.ImageField(upload_to='images')
   name=models.CharField(max_length=50)
   phone=models.CharField(max_length=50)
   email=models.EmailField(max_length=50)
   gender=models.CharField(max_length=50)
   password=models.CharField(max_length=8)
   p_val=models.BigIntegerField()

   def __str__(self):
      return self.name


class Image(models.Model):
    title = models.CharField(max_length=200)
    image = models.ImageField(upload_to='images')

    def __str__(self):
        return self.title