from django.apps import AppConfig


class CpchildappConfig(AppConfig):
    name = 'cpchildapp'
