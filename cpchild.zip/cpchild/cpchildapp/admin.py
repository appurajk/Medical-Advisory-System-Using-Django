from django.contrib import admin
from .models import User
from .models import Patient
# Register your models here.
admin.site.register(Patient)
@admin.register(User)
class User(admin.ModelAdmin):
    list_display=('id','username','password','name','phone','email','gender','specialization')
class Patient(admin.ModelAdmin):
    list_display=('id','image','name','phone','email','gender','p_val')


